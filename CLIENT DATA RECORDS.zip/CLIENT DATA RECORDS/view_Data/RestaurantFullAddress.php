
<?php 
 include('Database/db.php');
 include('header.php');
?>


<div class="col-sm-9">
  <div class="container">
  <h2 class="text-center">Restaurant Full Address</h2>



   <?php
    

        $business_id = $_SESSION['uid'];
        if(!$business_id){
          echo "Wrong Business Id";

        }else{
           

           $query = "SELECT  * FROM  client_details_list WHERE business_id ='$business_id ' ";
                  
           $result = mysqli_query($connection,$query);

            if (mysqli_num_rows($result) > 0) {
            
               echo '<table class="table table-bordered">
                         <thead class="table-hover">
                         <tr>
                            
                            <th class="bg-dark text-white">CLIENT ID</th>
                            <th class="bg-dark text-white">Restaurant Full Address </th>
                            <th class="bg-dark text-white">EDIT</th>
                            <th class="bg-dark text-white">UPDATE</th>
                            
                         </tr>
                        </thead>
                    <tbody>';

                    while ($row = mysqli_fetch_assoc($result)) {
                    
                        ?>

                        <tr>
                          <td><?php echo $row['CLIENT_ID'] ?></td>
                          <td><?php echo $row['R_ADDRESS'] ?></td>
                          <td><a href="?eid=<?php echo $row["CLIENT_ID"] ?>" class="btn btn-info" style="border-radius: 100px">EDIT</a></td>
                          <td> <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#basicExampleModal" style="border-radius: 100px">
                               Update Data
                             </button>
                           </td>
                        </tr>

                        <?php 
                    }
                    echo '</tbody>
                       </table>';  
            }

    }

           ?>    


   

        <!-- Modal -->
        <div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
          aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Resturant Full Address</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <div class="modal-body">


         <?php 
              if (isset($_REQUEST["eid"])) {
                # code...
                $eid = $_REQUEST["eid"];
                $query = mysqli_query($connection,"SELECT * FROM client_details_list WHERE CLIENT_ID = '$eid' ");

                $row = mysqli_fetch_array($query);
               
             }
             if(isset($_REQUEST["submit"])){
                $Restaurant = $_REQUEST['RestaurantFullAddress'];
                $result = mysqli_query($connection,"UPDATE client_details_list SET R_ADDRESS = '$Restaurant' WHERE CLIENT_ID = '$eid' ");

                if($result){
                  echo "Data Updated Please check";
                }else{
                  echo "Data Not Updated";
                }

             }
          ?>

      <form method="POST" onsubmit="return validateForm()" name="myForm">
        <div class="form-group">
          <label>Restaurant Full Address</label>
          <input type="text" name="RestaurantFullAddress" class="form-control" value="<?php echo $row['R_ADDRESS']; ?>">
           <input type="submit" name="submit" value="UPDATE" class="btn btn-primary mb-2">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          
      </form>



      </div>
    </div>
  </div>
</div>
            
   
</div>
    
</div><script>
function validateForm() {
  var x = document.forms["myForm"]["RestaurantFullAddress"].value;
  if (x == "") {
    alert("Restaurant Full Address Must be Filled out..");
    return false;
  }
}
</script>




<?php 
 include('footer.php');
?>