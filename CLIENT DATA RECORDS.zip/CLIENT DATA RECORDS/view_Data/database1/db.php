<?php 
	
	/*$servername1 = "localhost";
	$username1 = "root";
	$password1 = "";
	$dbname1 = "eatym_angaara";


	$connection1 = mysqli_connect("$servername1","$username1", "$password1", "$dbname1");

	if ($connection1) {
		# code...
		echo "connected";
	}else{
		echo "Not connected";
	}*/
	

	$servername2 = "localhost";
	$username2 = "root";
	$password2 = "";
	$dbname2 = "client_details_list";

	$connection2 = mysqli_connect("$servername2","$username2","$password2","$dbname2");


	/*if ($connection2) {
		# code...
		echo "connected";
	}else{
		echo "Not connected";
	}*/
	
?>


