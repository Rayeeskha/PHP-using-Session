
<?php 
 include('Database/db.php');
 include('header.php');
?>


<div class="col-sm-9">
    <h2 class="text-center">PINTEREST URL</h2>

     <?php
    

        $business_id = $_SESSION['uid'];


        if(!$business_id){
          echo "Wrong Business Id";

        }else{
           

           $query = "SELECT PINTEREST_URL FROM  client_details_list WHERE business_id ='$business_id ' ";
                  
           $result = mysqli_query($connection,$query);

            if (mysqli_num_rows($result) > 0) {
            
               echo '<table class="table table-bordered">
                         <thead class="table-hover">
                         <tr>
                            
                            <th class="bg-dark text-white">PINTEREST URL</th>
                         </tr>
                        </thead>
                    <tbody>';

                    while ($row = mysqli_fetch_assoc($result)) {
                    
                        echo '<tr>';
                        echo '<td><a href="https://in.pinterest.com/"><i class="fab fa-pinterest" style="color:red"></i>'
                         .$row['PINTEREST_URL']. '</td>';


                        
                           
                           echo "</tr>";
                    }
                    echo '</tbody>
                       </table>';  
            }

    }

           ?>    
            


           
                
     
</div>


<?php 
 include('footer.php');
?>