<?php
	include('database1/db.php');
	include('header.php');
?>




<div class="col-md-9">
	<h2 class="text-center">Client Details</h2>
	<table>
		<thead>
			<tr>
				
			</tr>
		</thead>
	</table>
</div>





<?php
	
	include('footer.php');
?>