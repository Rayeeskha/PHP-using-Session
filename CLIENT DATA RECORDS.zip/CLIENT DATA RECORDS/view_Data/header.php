<?php include "Database/db.php"; 
session_start();

?>






<!DOCTYPE html>
<html>
    <head>
        <title>Eatym Client Registration Form Data</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--awesome font include-->
        <link type="text/css" rel="stylesheet" href="assets/css/font-awesome.min.css" />
        <!--include plugin css--> 
        <link type="text/css" rel="stylesheet" href="src/jquery-rvnm.css" />


        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/font-awesome-5.8.1.css">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/mdb.css">
        <link rel="stylesheet" type="text/css" href="bootstrap/css/style.css">







          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>

        <script src="https://kit.fontawesome.com/yourcode.js"></script>


        <!--include jquery -->
        <script type="text/javascript" src="jquery.min.js"></script>
        <!--include plugin js-->
        <script type="text/javascript" src="src/jquery-rvnm.js"></script>

         <style>
            .clients_data button{
              margin: 10px 0px;
              width: 250px;
        }
  </style>

        <!--js run code-->
        <script type="text/javascript">
            $(function () {
                var rvnMenu = $("#navbar").rvnm({
//                    mode: 'mobile',
//                    responsive: false,
                    searchable: true,
                    theme: 'dark-lesb'
                });
                console.log(rvnMenu);
//                rvnMenu.setMode('minimal');
                rvnMenu.setTheme('dark-ruby');
            });
        </script>
    </head>
    <body style="margin-left: 22px;">

    <div class="w-100">
      <div class="row pt-2">
        <div class="col-md-2 col-lg-2 col-sm-6 col-12">
            <div class="col-md-3 col-lg-3 col-sm-3 col-3">
                 <img src="img/eatym_logo.png" class="img-responsive" style="width: 200px;height: 50px;">
        </div> 
        <!-- <div class="col-md-3 col-lg-3 col-sm-3 col-3">
          <h3>Restaurant Name</h3>
        </div> -->
          
        </div>
      </div>
        
        <div class="row">
            <div class="col-md-4 col-sm-12 col-lg-4">
                <nav id="navbar" class="">
            <ul>
                <li>
                    <a href="RestaurantName.php">  
                        <i class="fa fa-bell-o"></i>
                        Restaurant Name
                    </a>
                </li>
                <li>
                    <a href="RestaurantFullAddress.php">  
                        <i class="fa fa-bell-o"></i>
                        Restaurant Full Address
                    </a>
                </li>
                <li>
                    <a href="RestaurantOnMap.php">  
                        <i class="fa fa-bell-o"></i>
                        Restaurant On Map
                    </a>
                    

                </li>
                <li>
                    <a href="OwnerFullName.php">
                        <i class="fa fa-plus-square"></i>
                        Owner Full Name 
                    </a>
                    

                </li>
                <li>
                    <a href="OwnerEmailid.php">  
                        <i class="fa fa-bullhorn"></i>
                        Owner Email ID
                    </a>
                </li>
                <li>
                    <a href="OwnerPhoneNumber.php">  
                        <i class="fa fa-building"></i>
                        Owner Phone Number
                    </a>
                </li>
                <li>
                    <a href="RestaurantManager.php">  
                        <i class="fa fa-expand"></i>
                        Restaurant Manager Name
                    </a>
                </li>
                <li>
                    <a href="RestaurantManagerEmail.php"> 

                        
                        Restaurant Manager Email ID
                    </a>
                </li>
                <li>
                    <a href="RestaurantManagerPhone.php">  
                       
                        Restaurant Manager Phone Number
                    </a>
                </li>
                <li>
                    <a href="RestaurantEstablishment.php">
                        Restaurant Establishment Year
                    </a>
                </li>
                <li>
                    <a href="GstDetails.php">  
                        <i class="fa fa-expand"></i>
                        GST Details
                    </a>
                </li>
                <li>
                    <a href="ServiceBundle.php">  
                        <i class="fa fa-expand"></i>
                        Services Bundle
                    </a>
                    

                </li>
                <li>
                    <a href="Certifications.php">  
                        <i class="fa fa-address-book"></i>
                        Certifications
                    </a>
                </li>
                <li>
                    <a href="TotalStaff.php">  
                        <i class="fa fa-expand"></i>
                        Total Staff
                    </a>
                </li>
                <li>
                    <a href="FacebookURL.php">  
                        <i class="fa fa-yoast"></i>
                        Facebook URL
                    </a>
                    

                </li>
                <li>
                    <a href="TwitterURL.php">  
                        <i class="fa fa-bank"></i>
                        Twitter URL
                    </a>
                </li>
                <li>
                    <a href="YoutubeURL.php">  
                        <i class="fa fa-bank"></i>
                        Youtube URL
                    </a>
                </li>
                <li>
                    <a href="GooglePlusURL.php">  
                        <i class="fa fa-bank"></i>
                        Google Plus URL
                    </a>
                </li>
                <li>
                    <a href="InstagramURL.php">  
                        <i class="fa fa-bank"></i>
                        Instagram URL
                    </a>
                </li>
                <li>
                    <a href="Pinterest.php">  
                        <i class="fa fa-bank"></i>
                        Pinterest URL
                    </a>
                </li>
                <li>
                    <a href="CancelPassword.php">  
                        <i class="fa fa-bank"></i>
                        Cancel Password
                    </a>
                </li>
                <li>
                    <a href="RestaurantLogo.php">  
                        <i class="fa fa-bank"></i>
                        Restaurant Logo
                    </a>
                </li>
            </ul>

        </nav>

        </div>
    


        <div class="col-md-4 col-lg-4 col-sm-12 col-12 clients_data  text-center">
          <h3>Restaurant Name: 
            <?php 
                $business_id = $_SESSION['uid'];

                  if(!$business_id){

                      echo "Wrong Business ID";
                    }else{
                          $query = "SELECT R_NAME FROM  client_details_list WHERE business_id ='$business_id ' ";
                           $result = mysqli_query($connection,$query);

                            if (mysqli_num_rows($result) > 0) {
                            
                             while ($row = mysqli_fetch_assoc($result)) {
                                    
                                        echo '<tr>';
                                           echo'<td>'.$row['R_NAME'].'</td>';
                                    }
                                    echo '</tbody>
                                       </table>';  
                            }

                    }


            ?>

           </h3>

          </div>

           <div class="col-md-2 col-lg-4 col-sm-2 col-12 clients_data text-center">


            <!-----update data------>

                    

<!-- Central Modal Small -->


        </div>
      </div>

      <div style="border: 1px solid #e1e1e1;"></div></div>
      
    </div>


    </div>
        
            <div id="wrapper" class="col-md-6">
                
  <?php
      
      $business_id = $_SESSION['uid'];

      if(!$business_id){

          echo "Wrong Business ID";
        }
      else{
      

         $query = "SELECT * FROM  client_details_list WHERE business_id ='$business_id ' ";
                

            $result= mysqli_query($connection,$query);

        while($row = mysqli_fetch_array($result)) {
            # code...
            ?>
              

      

            <?php 
        }
    }

           ?>    


