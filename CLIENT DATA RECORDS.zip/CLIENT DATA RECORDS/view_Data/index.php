<?php include "Database/db.php"; 
session_start();
?>



<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title> Business Support Center</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <style type="text/css">
        #background{
            
            background-size: cover;
            height: 100vh;
            background-image: url("img/bms.jpg");
        }

    </style>


     <script>
        function validateForm() {
          var x = document.forms["myForm"]["business_id"].value;
          if (x == "") {
            alert("Business ID  must be filled out");
            return false;
          }
        }
    </script>


</head>
<body>

<div id="background">
<div class="container">

    <div class="text-center"><img src="img/eatym_logo.png" class="w-50 text-white" style="">
        <p style="font-size: 40px;font-weight: 400;" class="text-white"> Customer is king, be polite with him on call.</p>
    </div>

   

    <form action="" method="post" name="myForm"  onsubmit="return validateForm()">
        <div class="form-group py-5 text-center">
            <div class="row" style="margin-top:5px;">
                <div class="col-md-9 col-lg-9 col-sm-9 col-12 mt-3" >

                    <input type="text" name="business_id"  class="form-control pl-4" placeholder="Enter Business ID" id="" style="height:75px; font-size: 40px;font-weight: 400;border: 1px solid #b3b8bd;border-radius:30px;">
                </div>


                <div class="col-md-3 col-lg-3 col-sm-3 col-12 mt-3">
                    <button type="submit" name="search" class="btn btn-outline-primary" onclick="myFunction()" style="font-size: 32px;border-radius: 50px;padding: 15px 50px;"> Submit </button>
                </div>


                 <?php



                        if (isset($_POST['search'])) {
                                $uid = $_POST['business_id'];
                                
                                $result = mysqli_query($connection,"SELECT * FROM client_details_list WHERE business_id = '$uid'");

                                  if($row = mysqli_num_rows($result) == 1){

                                        $_SESSION['uid'] = $uid;
                                        header('location:header.php');
                                      

                                    }else{
                                        echo "<div class='alert alert-danger'>
                                              <strong>Warning!</strong> Enter Your Valid Business ID.
                                            </div>";
                                    }

                        }

            ?>



            </div>
            
            <i class="fa fa-address-card mt-5" aria-hidden="true" style="font-size: 20px;color: #fabd0a"></i>
        </div>
    </form>














</div>
</div>

</body>
</html>


  
