
<?php 
 include('Database/db.php');
 include('header.php');
?>


<div class="col-sm-9">
  <div class="container">
  <h2 class="text-center">Restaurant On Map</h2>



   <?php
    
     $business_id = $_SESSION['uid'];
        if(!$business_id){
          echo "Wrong Business Id";

        }else{
           

           $query = "SELECT  * FROM  client_details_list WHERE business_id ='$business_id ' ";
                  
           $result = mysqli_query($connection,$query);

            if (mysqli_num_rows($result) > 0) {
            
               echo '<table class="table table-bordered">
                         <thead class="table-hover">
                         <tr>
                            
                            <th class="bg-dark text-white">CLIENT ID</th>
                            <th class="bg-dark text-white">Restaurant On Map</th>
                            <th class="bg-dark text-white">EDIT</th>
                            <th class="bg-dark text-white">UPDATE</th>
                            
                         </tr>
                        </thead>
                    <tbody>';

                    while ($row = mysqli_fetch_assoc($result)) {
                    
                        ?>

                        <tr>
                          <td><?php echo $row['CLIENT_ID'] ?></td>


                          <td>
                            <a href="#"><i class="fas fa-map-marker-alt" style="color:red;">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15229.660566963415!2d78.46446213543544!3d17.39185378598254!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9762a6fc9667%3A0xd2958e64a71d7d24!2sAbids%2C%20Hyderabad%2C%20Telangana!5e0!3m2!1sen!2sin!4v1578654566609!5m2!1sen!2sin" width="200" height="200" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                            </i><?php echo $row['RS_MAP'] ?>
                         </td>
                        <td>
                          <a href="?eid=<?php echo $row["CLIENT_ID"] ?>" class="btn btn-info" style="border-radius: 100px;">EDIT</a>
                        </td>
                          <td> <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#basicExampleModal" style="border-radius: 100px;">
                               Update 
                             </button>
                           </td>
                        </tr>

                        <?php 
                    }
                    echo '</tbody>
                       </table>';  
            }

        }

  ?>    
   <!-- Modal -->
        <div class="modal fade" id="basicExampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
          aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Resturant On Map</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <div class="modal-body">


         <?php 
              if (isset($_REQUEST["eid"])) {
                # code...
                $eid = $_REQUEST["eid"];
                $query = mysqli_query($connection,"SELECT * FROM client_details_list WHERE CLIENT_ID = '$eid' ");

                $row = mysqli_fetch_array($query);
               
             }
             if(isset($_REQUEST["submit"])){
                $Restaurant = $_REQUEST['RestaurantOnMap'];
                $result = mysqli_query($connection,"UPDATE client_details_list SET RS_MAP = '$Restaurant' WHERE CLIENT_ID = '$eid' ");

                if($result){
                  echo "Data Updated Please check";
                }else{
                  echo "Data Not Updated";
                }

             }
          ?>

      <form method="POST" onsubmit="return validateForm()" name="myForm">
        <div class="form-group">
          <label>Restaurant On Map</label>
          <input type="text" name="RestaurantOnMap" class="form-control" value="<?php echo $row['RS_MAP']; ?>">
           <input type="submit" name="submit" value="UPDATE" class="btn btn-primary mb-2">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          
      </form>



      </div>
    </div>
  </div>
</div>
            
   
</div>
 
                
     
</div>
<script>
function validateForm() {
  var x = document.forms["myForm"]["RestaurantOnMap"].value;
  if (x == "") {
    alert("Restaurant On Map Must be Filled out..");
    return false;
  }
}
</script>

<?php 
 include('footer.php');
?>