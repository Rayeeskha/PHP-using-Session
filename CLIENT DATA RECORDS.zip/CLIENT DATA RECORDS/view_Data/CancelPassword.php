
<?php 
 include('Database/db.php');
 include('header.php');
?>


<div class="col-sm-9">
    <h2 class="text-center">CANCEL PASSWORD</h2>

     <?php
    

        $business_id = $_SESSION['uid'];


        if(!$business_id){
          echo "Wrong Business Id";

        }else{
           

           $query = "SELECT CANCEL_PASSWORD FROM  client_details_list WHERE business_id ='$business_id ' ";
                  
           $result = mysqli_query($connection,$query);

            if (mysqli_num_rows($result) > 0) {
            
               echo '<table class="table table-bordered">
                         <thead class="table-hover">
                         <tr>
                            
                            <th class="bg-dark text-white">CANCEL PASSWORD</th>
                         </tr>
                        </thead>
                    <tbody>';

                    while ($row = mysqli_fetch_assoc($result)) {
                    
                        echo '<tr>';
                        echo '<td>'
                         .$row['CANCEL_PASSWORD']. '</td>';


                        
                           
                           echo "</tr>";
                    }
                    echo '</tbody>
                       </table>';  
            }

    }

           ?>    
            


           
                
     
</div>


<?php 
 include('footer.php');
?>